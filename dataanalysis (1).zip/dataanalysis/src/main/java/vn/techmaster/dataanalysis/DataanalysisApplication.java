package vn.techmaster.dataanalysis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataanalysisApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataanalysisApplication.class, args);
	}

}
